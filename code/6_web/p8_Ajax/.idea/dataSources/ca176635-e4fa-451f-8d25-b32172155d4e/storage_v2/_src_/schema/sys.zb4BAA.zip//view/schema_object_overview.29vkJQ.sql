CREATE VIEW schema_object_overview AS
  SELECT
    `routines`.`ROUTINE_SCHEMA` AS `db`,
    `routines`.`ROUTINE_TYPE`   AS `object_type`,
    count(0)                    AS `count`
  FROM `information_schema`.`ROUTINES`
  GROUP BY `routines`.`ROUTINE_SCHEMA`, `routines`.`ROUTINE_TYPE`
  UNION SELECT
          `tables`.`TABLE_SCHEMA` AS `TABLE_SCHEMA`,
          `tables`.`TABLE_TYPE`   AS `TABLE_TYPE`,
          count(0)                AS `COUNT(*)`
        FROM `information_schema`.`TABLES`
        GROUP BY `tables`.`TABLE_SCHEMA`, `tables`.`TABLE_TYPE`
  UNION SELECT
          `statistics`.`TABLE_SCHEMA`                       AS `TABLE_SCHEMA`,
          concat('INDEX (', `statistics`.`INDEX_TYPE`, ')') AS `CONCAT('INDEX (', INDEX_TYPE, ')')`,
          count(0)                                          AS `COUNT(*)`
        FROM `information_schema`.`STATISTICS`
        GROUP BY `statistics`.`TABLE_SCHEMA`, `statistics`.`INDEX_TYPE`
  UNION SELECT
          `triggers`.`TRIGGER_SCHEMA` AS `TRIGGER_SCHEMA`,
          'TRIGGER'                   AS `TRIGGER`,
          count(0)                    AS `COUNT(*)`
        FROM `information_schema`.`TRIGGERS`
        GROUP BY `triggers`.`TRIGGER_SCHEMA`
  UNION SELECT
          `events`.`EVENT_SCHEMA` AS `EVENT_SCHEMA`,
          'EVENT'                 AS `EVENT`,
          count(0)                AS `COUNT(*)`
        FROM `information_schema`.`EVENTS`
        GROUP BY `events`.`EVENT_SCHEMA`
  ORDER BY `db`, `object_type`;

